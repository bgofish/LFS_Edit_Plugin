# SPDX-License-Identifier: GPL-3.0-or-later
"""Modal point picker for the Align feature.

Replaces the old hover-polling approach with a proper modal operator that
uses sel.pick_at_screen() on left-click — identical pattern to the
measurement_tool's MEASURE_OT_pick_point, which works reliably.

Usage
-----
1. Call set_capture_callback(fn, point_num) then invoke the operator:
       lf.ui.ops.invoke("lfs_plugins.EDIT.operators.align_picker.ALIGN_OT_pick_point")
2. When the user left-clicks on the model, fn(world_pos, point_num) is called
   and the operator exits automatically.
3. ESC / right-click cancels and sets the cancelled flag (was_capture_cancelled()).
"""

import lichtfeld as lf
import lichtfeld.selection as sel
from lfs_plugins.types import Operator, Event

# ── Module-level callback state ────────────────────────────────────────────────
_capture_callback  = None
_capture_point_num = 0
_capture_cancelled = False


def set_capture_callback(callback, point_num: int):
    """Register the function to call when a point is successfully picked."""
    global _capture_callback, _capture_point_num, _capture_cancelled
    _capture_callback  = callback
    _capture_point_num = point_num
    _capture_cancelled = False
    lf.log.info(f"ALIGN_PICK set_capture_callback: point_num={point_num}")


def clear_capture_callback():
    """Cancel any pending pick and reset state."""
    global _capture_callback, _capture_point_num, _capture_cancelled
    lf.log.info("ALIGN_PICK clear_capture_callback")
    _capture_callback  = None
    _capture_point_num = 0
    _capture_cancelled = True


def was_capture_cancelled() -> bool:
    """Returns True (once) if the last pick was cancelled rather than completed."""
    global _capture_cancelled
    if _capture_cancelled:
        _capture_cancelled = False
        return True
    return False


# ── Compatibility shims for transform_panel code that used the old API ─────────
# The panel called poll_hover() / capture_hovered_point() / get_hovered_pos().
# These stubs keep the panel importable without error; the panel's on_update
# polling of poll_hover() is now a no-op (the modal operator handles everything).

def poll_hover() -> bool:
    """No-op shim — picking is now handled by the modal operator."""
    return False


def capture_hovered_point() -> bool:
    """No-op shim — the modal operator fires the callback directly on click."""
    return False


def get_hovered_pos():
    """Always returns None — hover state is no longer tracked."""
    return None


# ── Modal operator ─────────────────────────────────────────────────────────────

class ALIGN_OT_pick_point(Operator):
    """Modal operator: click on the model to pick an alignment point.

    Left-click      → pick the point under the cursor and exit.
    Right-click/ESC → cancel.
    """

    label       = "Pick Alignment Point"
    description = "Click on the model to pick a point for alignment"
    options     = {'BLOCKING'}

    def invoke(self, context, event: Event) -> set:
        """Start modal mode immediately."""
        lf.log.info("ALIGN_PICK invoke → RUNNING_MODAL")
        return {'RUNNING_MODAL'}

    def modal(self, context, event: Event) -> set:
        global _capture_callback, _capture_point_num

        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            result = sel.pick_at_screen(event.mouse_region_x, event.mouse_region_y)

            if result is not None and _capture_callback is not None:
                world_pos = result.world_position
                lf.log.info(
                    f"ALIGN_PICK modal: hit at "
                    f"({world_pos[0]:.4f}, {world_pos[1]:.4f}, {world_pos[2]:.4f})"
                    f"  point_num={_capture_point_num}"
                )
                _capture_callback(world_pos, _capture_point_num)
                # Callback consumed — clear state and finish.
                _capture_callback  = None
                _capture_point_num = 0
                return {'FINISHED'}

            # Missed the model — keep waiting.
            lf.log.info("ALIGN_PICK modal: left-click missed model, waiting…")
            return {'RUNNING_MODAL'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            lf.log.info("ALIGN_PICK modal: cancelled")
            clear_capture_callback()
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def cancel(self, context):
        """Called by the framework if the operator is cancelled externally."""
        clear_capture_callback()
